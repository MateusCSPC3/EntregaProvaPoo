#include <iostream>
#include <vector>
#include <string>
#include "Veiculo.h"

using namespace std;

const float COMBUSTIVEL_TESTE = 30.0;

int main() {
    
    vector<Veiculo> veiculos = {
        Veiculo("Ford Fiesta", "Preto", 2009, 15.7),
        Veiculo("Honda HR-V", "Azul", 2018, 13.0),
        Veiculo("VolksWagen Gol", "Branco", 2010, 20.8),
        Veiculo("VolksWagen Saveiro", "Vermelha", 2004, 20.5),
        Veiculo("Nissan GTR R34", "Roxo", 2000, 5.2)
    };

    cout << " LISTA INICIAL DE VEÍCULOS" << endl;
    for (size_t i = 0; i < veiculos.size(); ++i) {
        cout << "\nVeículo " << i + 1 << ":" << endl;
        veiculos[i].exibirDados();
    }
    cout << endl;
    
    Veiculo& Veiculo1 = veiculos[0];
    
    cout << "teste de getter" << endl;
    cout << "Modelo Atual: " << Veiculo1.getModelo() << endl;
    cout << "Cor Atual: " << Veiculo1.getCor() << endl;

    string novoModelo = "Ford Ka";
    string novaCor = "Cinza";
    
    Veiculo1.setModelo(novoModelo);
    Veiculo1.setCor(novaCor);
    
    
    cout << "alterado para: " << novoModelo << endl;
    cout << "alterado para: " << novaCor << endl;


    cout << "Novo Modelo: " << Veiculo1.getModelo() << endl;
    cout << "Nova Cor: " << Veiculo1.getCor() << endl;
    cout << "\nDados Completos do Veículo 1 após Alteração:" << endl;
    Veiculo1.exibirDados();
   

    cout << "\n CÁLCULO DE AUTONOMIA COM " << COMBUSTIVEL_TESTE << " LITROS" << endl;
    for (size_t i = 0; i < veiculos.size(); ++i) {
        float autonomia = veiculos[i].calcularAutonomia(COMBUSTIVEL_TESTE); 
        
        cout << "\nVeículo: " << veiculos[i].getModelo() << " (" << veiculos[i].getAnoFabricacao() << ")" << endl;
        cout << "Consumo: " << veiculos[i].getKMPorLitro() << " km/l" << endl;
        cout << "Autonomia com " << COMBUSTIVEL_TESTE << " litros: " << autonomia << " km" << endl;
    }
    

    return 0;
}