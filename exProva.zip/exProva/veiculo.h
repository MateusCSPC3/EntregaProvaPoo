#ifndef VEICULO_H
#define VEICULO_H

#include <string>
#include <iostream>

using namespace std;

class Veiculo {
private:
    string modelo;
    string cor;
    int anoFabricacao;
    float KMPorLitro;

public:
    
    Veiculo(string modelo, string cor, int anoFabricacao, float KMPorLitro) :
        modelo(modelo), cor(cor), anoFabricacao(anoFabricacao), KMPorLitro(KMPorLitro) {}

    
    void setModelo(string modelo) {
        this->modelo = modelo;
    }

    void setCor(string cor) {
        this->cor = cor;
    }

    void setAnoFabricacao(int anoFabricacao) {
        this->anoFabricacao = anoFabricacao;
    }

    void setKMPorLitro(float KMPorLitro) {
        this->KMPorLitro = KMPorLitro;
    }

    
    string getModelo() const {
        return modelo;
    }

    string getCor() const {
        return cor;
    }

    int getAnoFabricacao() const {
        return anoFabricacao;
    }

    float getKMPorLitro() const {
        return KMPorLitro;
    }

    
    void exibirDados() const {
        cout << "Modelo: " << modelo << endl;
        cout << "Cor: " << cor << endl;
        cout << "Ano de Fabricação: " << anoFabricacao << endl;
        cout << "Quilometragem por Litro: " << KMPorLitro << endl;
    }

    
    float calcularAutonomia(float totalCombustivel) const {
        return totalCombustivel * KMPorLitro;
    }
};

#endif